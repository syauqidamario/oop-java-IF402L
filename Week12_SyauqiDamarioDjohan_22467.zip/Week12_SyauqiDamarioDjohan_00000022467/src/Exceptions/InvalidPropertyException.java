package Exceptions;

public class InvalidPropertyException extends Exception{
	public InvalidPropertyException(){
		super("Input Data Tidak Valid");
	}

	public InvalidPropertyException(String message){
		super(message);
	}
}