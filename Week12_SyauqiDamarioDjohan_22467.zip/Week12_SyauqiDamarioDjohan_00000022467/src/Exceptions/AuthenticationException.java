package Exceptions;

public class AuthenticationException extends Exception{
	public AuthenticationException(){
		super("Anda Telah Mencapai Jumlah Batas Login");
	}

	public AuthenticationException(String message){
		super(message);
	}
}