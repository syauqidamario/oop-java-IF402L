package Exceptions;

public class ExcessiveFailedLoginException extends Exception{
	public ExcessiveFailedLoginException(){
		super("Anda Telah Mencapai Jumlah Batas Login");
	}

	public ExcessiveFailedLoginException(String message){
		super(message);
	}

}