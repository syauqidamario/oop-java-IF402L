package Main;

import java.util.ArrayList;
import java.util.Scanner;
import Exceptions.*;
import Users.User;

public class Main {
	
	public static ArrayList<User> listOfUser = new ArrayList<User>();

	public static void Initialize(){
		listOfUser.add(new User("John", "Doe", 'L', "Jl. Merpati No. 1 RT 1 RW 1, Banten", "admin", "admin"));
	}

	public static void handleLogin(String username, String password) throws ExcessiveFailedLoginException, AuthenticationException{
		boolean success = false;
		
		try{
			for(int i = 0; i < listOfUser.size(); i++)
			{
				success = listOfUser.get(i).login(username, password);
				
				if(success == true)
				{
					throw new AuthenticationException(listOfUser.get(i).greeting() + listOfUser.get(i).getFirstName() + " " + listOfUser.get(i).getLastName());
				}
			}
			
			System.out.println("Username / Password Salah");
		}
		catch (ExcessiveFailedLoginException e){
			throw new ExcessiveFailedLoginException();
		}		
	}

	public static void handleSignUp(String firstName, String lastName, Character gender, String address, String userName, String password){
		boolean panjang = false, besar = false, angka = false;
		
		if(password.length() >= 6 && password.length() <= 16){
			panjang = true;
			
			for(int i = 0; i < password.length(); i++){
				if(Character.isUpperCase(password.charAt(i))){
					besar = true;
				}
				else if(Character.isDigit(password.charAt(i))){
					angka = true;
				}
			}
			
			if(panjang && besar && angka){
				listOfUser.add(new User(firstName, lastName, gender, address, userName, password));
			}
			else {
				System.out.println("Password Harus Mengandung Huruf Besar, ANgka, Minimum 6 Karakter Dan Maksimum 16 Karakter");
			}			
		}
		
	}

	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);

		int pilih;
		String username, password, fistName, lastName, address;
		Character gender;

		Initialize();

		while(true){
			System.out.println("1. Login");
			System.out.println("2. Sign Up");
			System.out.print("Pilihan : ");
			pilih = scanner.nextInt();

			if(pilih == 1){
				while(true){
					try{
						System.out.print("Username \t : ");
						username = scanner.next();
						System.out.print("Password \t : ");
						password = scanner.next();

						handleLogin(username, password);
					} 
					catch (ExcessiveFailedLoginException | AuthenticationException Ex){
						System.out.println(Ex.getMessage());
						
						break;
					}
				}
			}
			else if(pilih == 2){
				while(true)
				{
					System.out.print("Nama Depan \t : ");
					fistName = scanner.next();
					System.out.print("Nama Belakang \t : ");
					lastName = scanner.next();
					System.out.print("Jenis Kelamin (L/P) : ");
					gender = scanner.next().charAt(0);
					System.out.print("Alamat \t\t : ");
					address = scanner.nextLine();
					address = scanner.nextLine();

					System.out.print("Username \t : ");
					username = scanner.next();

					if(username.length() < 8){
						System.out.println("Username Harus Lebih Dari 8 Karakter");
					}

					System.out.print("Password \t : ");
					password = scanner.next();

					handleSignUp(fistName, lastName, gender, address, username, password);

					break;
				}

			}
			else if(pilih == 0) {
				scanner.close();
				break;
			}
		}
	}
}