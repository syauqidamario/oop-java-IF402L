package week09.syauqi.id.ac.umn;

public class Tetap extends Karyawan {
	public Tetap() {
		
	}
	
	public Tetap(String id, String nama) {
		super(id,nama);
	}
	
	public int getGaji() {
		return 3000000;
	}

}
