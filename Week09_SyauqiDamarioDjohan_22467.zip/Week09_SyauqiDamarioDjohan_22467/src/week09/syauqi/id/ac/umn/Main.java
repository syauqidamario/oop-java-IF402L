package week09.syauqi.id.ac.umn;

import java.util.Scanner;
import java.util.concurrent.atomic.AtomicInteger;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

public class Main {
	public static Manager[] manager = new Manager[200];
	public static Tetap[] tetap = new Tetap[200];
	public static Magang[] magang = new Magang[200];

	private static AtomicInteger ID_Manager = new AtomicInteger(1);
	private static AtomicInteger ID_Tetap = new AtomicInteger(1);
	private static AtomicInteger ID_Magang = new AtomicInteger(1);
	
	public static Scanner scanner = new Scanner(System.in);
	
	public static void SeedNull()
	{
		for(int i = 0; i < 50; i++)
		{
			manager[i] = null;
			tetap[i] = null;
			magang[i] = null;
		}
	}
	
	public static int AddManager(int managers)
	{
		String name;

		System.out.print("Nama \t : ");
		scanner.nextLine();
		name = scanner.nextLine();

		int ID_MA = ID_Manager.getAndIncrement();
		String ID = "M" + ID_MA;

		manager[managers] = new Manager(ID, name);
		managers++;
		System.out.println("Manager Baru Telah Ditambahkan");

		return managers;
	}
	
	public static int AddTetap(int tetaps)
	{
		String name;

		System.out.print("Nama \t : ");
		scanner.nextLine();
		name = scanner.nextLine();

		int ID_K = ID_Tetap.getAndIncrement();
		String ID = "R" + ID_K;

		tetap[tetaps] = new Tetap(ID, name);
		tetaps++;
		System.out.println("Karyawan Tetap Baru Telah Ditambahkan");

		return tetaps;
	}
	
	public static int AddMagang(int magangs)
	{
		String name;

		System.out.print("Nama \t : ");
		scanner.nextLine();
		name = scanner.nextLine();

		int ID_M = ID_Magang.getAndIncrement();
		String ID = "I" + ID_M;

		magang[magangs] = new Magang(ID, name);
		magangs++;
		System.out.println("Karyawan Magang Baru Telah Ditambahkan");

		return magangs;
	}
	
	public static void SeeEmployees()
	{
		DecimalFormat kursIndonesia = (DecimalFormat) DecimalFormat.getCurrencyInstance();
        DecimalFormatSymbols formatRp = new DecimalFormatSymbols();

        formatRp.setCurrencySymbol("Rp. ");
        formatRp.setMonetaryDecimalSeparator(',');
        formatRp.setGroupingSeparator('.');

        kursIndonesia.setDecimalFormatSymbols(formatRp);

		System.out.println("-----Daftar Manager-----");

		if(manager[0] == null)
		{
			System.out.println("Tidak Ada");
		}
		else
		{
			for(int i = 0; i < manager.length; i++)
			{
				if(manager[i] == null)
				{
					break;
				}
				else
				{
					System.out.println("ID \t : " + manager[i].getId());
					System.out.println("Nama \t : " + manager[i].getNama());
					System.out.printf("Gaji \t : %s %n", kursIndonesia.format(manager[i].getGaji()));
					System.out.println("--------------------------");
				}
			}
		}

		//--------------------------------------------------------------------

		System.out.println("-----Daftar Karyawan Tetap-----");

		if(tetap[0] == null)
		{
			System.out.println("Tidak Ada");
		}
		else
		{
			for(int i = 0; i < tetap.length; i++)
			{
				if(tetap[i] == null)
				{
					break;
				}
				else
				{
					System.out.println("ID \t : " + tetap[i].getId());
					System.out.println("Nama \t : " + tetap[i].getNama());
					System.out.printf("Gaji \t : %s %n", kursIndonesia.format(tetap[i].getGaji()));
					System.out.println("--------------------------");
				}
			}
		}

		System.out.println("-----Daftar Karyawan Magang-----");

		if(magang[0] == null)
		{
			System.out.println("Tidak Ada");
		}
		else
		{
			for(int i = 0; i < magang.length; i++)
			{
				if(magang[i] == null)
				{
					break;
				}
				else
				{
					System.out.println("ID \t : " + magang[i].getId());
					System.out.println("Nama \t : " + magang[i].getNama());
					System.out.printf("Gaji \t : %s %n", kursIndonesia.format(magang[i].getGaji()));
					System.out.println("--------------------------");
				}
			}
		}
	}

	public static void main(String[] args) {
		int pilih, manager = 0, tetap = 0, magang = 0;

		SeedNull();

		while (true)
		{
			System.out.println("-----Program Data karyawan-----");
			System.out.println("1. Lihat Karyawan");
			System.out.println("2. Tambah Karyawan");
			System.out.println("3. Keluar");
			System.out.print("Pilih : ");
			pilih = scanner.nextInt();

			if(pilih == 1) 
			{
				SeeEmployees();

				System.out.println();
			}
			else if(pilih == 2) 
			{
				System.out.println("-----Tambah karyawan-----");
				System.out.println("1. Manager");
				System.out.println("2. Karyawan Tetap");
				System.out.println("3. Karyawan Magang");
				System.out.print("Pilih : ");
				pilih = scanner.nextInt();

				if(pilih == 1) 
				{
					manager = AddManager(manager);
				}
				else if(pilih == 2) 
				{
					tetap = AddTetap(tetap);
				}
				else if(pilih == 3) 
				{
					magang = AddMagang(magang);
				}

				System.out.println();
			}
			else if(pilih == 3) // Keluar
			{
				scanner.close();

				break;
			}
			else
			{
				continue;
			}
		}
	}
}