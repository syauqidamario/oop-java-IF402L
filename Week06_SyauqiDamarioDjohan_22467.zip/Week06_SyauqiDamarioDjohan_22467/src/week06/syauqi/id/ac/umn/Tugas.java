package week06.syauqi.id.ac.umn;

import java.util.Scanner;

public class Tugas {
	static Handphone[] handphones= new Handphone[50];
	static Voucher[] vouchers= new Voucher[50];
	static Order[] orders = new Order[50];
	
	public static void pesanBarang() {
		Scanner in = new Scanner(System.in);
		int pilihan;
		int id;
		int jumlah;
		int uang;
		
		System.out.println("Daftar Barang Toko Voucher & HP");
		System.out.println("1. Handphone");
		System.out.println("2. Voucher");
		System.out.println("Pilihan: ");
		pilihan = in.nextInt();
		
		if(pilihan==1) {
			for(int i=0; i<Handphone.total; i++) {
				System.out.println("ID    : "+ handphones[i].getId());
				System.out.println("Nama  : "+ handphones[i].getNama());
				System.out.println("Stock : "+ handphones[i].getStock());
				System.out.println("Harga : "+ handphones[i].getHarga());
				System.out.println("---------------------------");
			}
			System.out.println("Ketik 0 untuk batal");
			System.out.print("Pesan Barang (ID): ");
			id = in.nextInt();
			if(id <= Handphone.total && id > 0) {
				id--;
				System.out.print("Masukkan Jumlah : ");
				jumlah = in.nextInt();
				if(jumlah > handphones[id].getStock()) {
					System.out.println("Stok tidak mencukupi");
				}
				else {
					System.out.println(jumlah + " @ " + handphones[id].getNama() + " dengan total harga " + jumlah*handphones[id].getHarga());
					
					System.out.print("Masukkan Jumlah Uang: ");
					uang = in.nextInt();
					
					if(uang >= jumlah*handphones[id].getHarga()) {
						System.out.println("Berhasil dipesan");
						orders[Order.total] = new Order("OH"+Order.total, handphones[id], jumlah);
						Order.total++;
						handphones[id].minusStock(jumlah);
					}
					else {
						System.out.println("Jumlah uang tidak mencukupi");
					}
				}
			}
		}
		else if(pilihan==2) {
			for(int i=0; i<Voucher.total; i++) {
				System.out.println("ID    : "+ vouchers[i].getId());
				System.out.println("Nama  : "+ vouchers[i].getNama());
				System.out.println("Nominal: "+ vouchers[i].getHarga());
				System.out.println("Stock : "+ vouchers[i].getStock());
				System.out.println("Harga : "+ vouchers[i].getHargaJual());
				System.out.println("---------------------------");
			}
			System.out.println("Ketik 0 untuk batal");
			System.out.print("Pesan Barang (ID): ");
			id = in.nextInt();
			if(id <= Voucher.total && id > 0) {
				id--;
				System.out.print("Masukkan Jumlah : ");
				jumlah = in.nextInt();
				if(jumlah > vouchers[id].getStock()) {
					System.out.println("Stok tidak mencukupi");
				}
				else {
					System.out.println(jumlah+ " @ " + vouchers[id].getNama()+ " "+ vouchers[id].getHarga() + " dengan harga " + jumlah*vouchers[id].getHargaJual());
				}
				System.out.print("Masukkan Jumlah Uang: ");
				uang = in.nextInt();
				if(uang >= jumlah*vouchers[id].getHarga()) {
					System.out.println("Berhasil dipesan");
					orders[Order.total] = new Order("OV"+Order.total, vouchers[id], jumlah);
					Order.total++;
					vouchers[id].minusStock(jumlah);
				}
				else {
					System.out.println("Jumlah uang tidak mencukupi");
				}
			}
		}
	}
	
	public static void lihatPesanan() {
		System.out.println("Daftar Pesanan Toko Multiguna");
		
		for(int i=0; i<Order.total; i++) {
			System.out.println("------------------------");
			System.out.println("ID    : "+ orders[i].getId());
			if(orders[i].getId().equals("OV"+i)) {
				System.out.println("Nama  : "+ orders[i].getVoucher().getNama());
				System.out.println("Jumlah: "+ orders[i].getJumlah());
				System.out.println("Total : "+ orders[i].getJumlah()*orders[i].getVoucher().getHarga());
				System.out.println("------------------------");
			}
			else if(orders[i].getId().equals("OH"+i)){
				System.out.println("Nama  : "+ orders[i].getHandphone().getNama());
				System.out.println("Jumlah: "+ orders[i].getJumlah());
				System.out.println("Total : "+ orders[i].getJumlah()*orders[i].getHandphone().getHarga());
				System.out.println("------------------------");
			}			
		}
	}
	
	public static void barangBaru() {
		Scanner in = new Scanner(System.in);
		String tipe, nama, Warna;
		int harga;
		int stok;
		double ppn;

		for(;;) {
			System.out.print("Voucher / Handphone (V/H): ");
			tipe = in.nextLine();
			
			if(tipe.equals("v") || tipe.equals("V")) {
				System.out.print("Nama : ");
				nama = in.nextLine();
				System.out.print("Harga : ");
				harga= in.nextInt();
				System.out.print("Stok: ");
				stok = in.nextInt();
				System.out.print("PPN :");
				ppn = in.nextDouble();
				vouchers[Voucher.total]= new Voucher(Voucher.total+1, nama, harga, stok, ppn);
				Voucher.total++;
				System.out.println("Voucher telah berhasil diinput");
				break;
			}
			else if(tipe.equals("h") || tipe.equals("H")){
				System.out.print("Nama : ");
				nama = in.nextLine();
				System.out.print("Harga : ");
				harga= in.nextInt();
				System.out.print("Stok: ");
				stok = in.nextInt();
				System.out.print("Warna :");
				Warna = in.nextLine();
				in.nextLine();
				handphones[Handphone.total]= new Handphone(Handphone.total+1, nama, harga, stok, Warna);
				Handphone.total++;
				System.out.println("Handphone telah berhasil diinput");
				break;
			}
			else {
				System.out.println("Input tidak valid");
				continue;
			}
				
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		
		int menu;
		
		for(;;) {
			System.out.println("------Menu Toko Voucher & HP-----");
			System.out.println("1. Pesan Barang");
			System.out.println("2. Lihat Pesanan");
			System.out.println("3. Barang Baru");
			System.out.println("Pilihan : ");
			menu = in.nextInt();
			
			switch(menu) {
			case 1:
				pesanBarang();
				break;
			
			case 2:
				lihatPesanan();
				break;
				
			case 3:
				barangBaru();
				break;
				
			default:
				System.out.println("Input tidak valid");
			}	
		}
	}
}
	
	

	