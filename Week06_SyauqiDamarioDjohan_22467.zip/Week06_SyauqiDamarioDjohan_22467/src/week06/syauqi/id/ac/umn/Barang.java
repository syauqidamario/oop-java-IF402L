package week06.syauqi.id.ac.umn;

public class Barang {
	protected int id;
	protected int stock;
	protected double harga;
	protected String nama;
	
	public Barang(int id, double harga, String nama) {
		this.id = id;
		this.nama = nama;
		this.harga = harga;	
	}
	
	public void minusStock(int quantity) {
		this.stock = -quantity;
	}
	
	public int getid() {
		return id;
	}
	
	public String getNama() {
		return nama;
	}
	
	public double getHarga() {
		return harga;
	}
	
	public int getStock() {
		return stock;
	}
}
