package tugas01.syauqi.umn.ac.id;

import java.util.Scanner;

public class Main 
{
	static Barang[] barangs = new Barang[5];
	public static Pesanan[] pesanans = new Pesanan[5];
	
	public static void seedBarang()
	{
		barangs[0] = new Barang (1, "Pulpen Easy Gel 0.5mm", 120, 2000);
		barangs[1] = new Barang (2, "Penggaris 30Cm", 30, 5000);
		barangs[2] = new Barang (3, "Tipe-x Roller", 30, 7000);
		barangs[3] = new Barang (4, "Pensil Mekanik", 50, 5000);
		barangs[4] = new Barang (5, "Buku Tulis", 100, 6000);
	}
	
	public static void showBarang()
	{
		System.out.println("Daftar Barang Toko Multiguna");

		for(Barang barang : barangs)
		{
			System.out.println("ID \t : " + barang.getId());
			System.out.println("Nama \t : " + barang.getNama());
			System.out.println("Stock \t : " + barang.getStock());
			System.out.println("Harga \t : " + barang.getHarga());
			System.out.println("---------------------------------");
		}
		
		System.out.println("Ketik 0 Untuk Batal");
		System.out.print("Pesan Barang (ID) : ");
	}
	
	public static int inputPesanan(int pesan, int jumlah, int id) 
	{
		int cek = 0, count = 0;
		
		if(pesan == 0)
		{
			
		}
		else 
		{
			for(int  i = 0;  i < pesan;  i++) 
			{
				if (pesanans[i].getBarang().getNama().contains(barangs[id].getNama())) 
				{
					cek = 1;
				}
				
				if(cek == 1)
				{
					break;
				}
				
				count++;
			}
		}
		
		if(cek == 0)
		{
			pesanans[pesan] = new Pesanan ((pesan + 1), jumlah, barangs[id]);
					
			return (pesan + 1);
		}
		else 
		{
			pesanans[count] = new Pesanan ((count + 1), (jumlah + pesanans[count].getJumlah()), barangs[id]);
			
			return pesan;
		}
	}
	
	public static void showPesanan(int count) 
	{
		int total = 0, total1;
		
		System.out.println("Daftar Pesanan Toko Multiguna");
		
		if(count > 1)
		{
			for(int i = 0; i < count; i++)
			{
				System.out.println("Id \t : " + pesanans[i].getId());
				System.out.println("Nama \t : " + pesanans[i].getBarang().getNama());
				System.out.println("Jumlah \t : " + pesanans[i].getJumlah());
				System.out.println("Total \t : " + pesanans[i].total(pesanans[i].getJumlah(), pesanans[i].getBarang()));
				System.out.println("---------------------------------");
				
				total1 = pesanans[i].total(pesanans[i].getJumlah(), pesanans[i].getBarang());
				
				total = total + total1;
			}
		}
		else 
		{
			System.out.println("Id \t : " + pesanans[count - 1].getId());
			System.out.println("Nama \t : " + pesanans[count - 1].getBarang().getNama());
			System.out.println("Jumlah \t : " + pesanans[count - 1].getJumlah());
			System.out.println("Total \t : " + pesanans[count - 1].total(pesanans[count - 1].getJumlah(), pesanans[count - 1].getBarang()));
			System.out.println("---------------------------------");
			
			total1 = pesanans[count - 1].total(pesanans[count - 1].getJumlah(), pesanans[count - 1].getBarang());
			
			total = total + total1;
		}
		
		System.out.println("Total : " + total);		
	}
	
	
	public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
		
		int pesan, jmlh, uang, count = 0, input;

		seedBarang();

		for(;;)
		{
			System.out.println("------------Menu Toko Multiguna------------");
			System.out.println("1. Pesan Barang");
			System.out.println("2. Lihat Barang");
			System.out.print("Pilihan : ");
			int pilihan = scanner.nextInt();

			if(pilihan == 1)
			{
				showBarang();
				
				pesan = scanner.nextInt();
				
				if(pesan > 0 && pesan <6)
				{
					pesan--;
					
					while (true) 
					{
						System.out.print("Masukkan Jumlah : ");
						jmlh = scanner.nextInt();
						
						if(jmlh <= barangs[pesan].getStock() && jmlh > 0)
						{
							break;
						}
					}
					
					System.out.println(jmlh + " @ " + barangs[pesan].getNama() + " dengan total harga " + (jmlh * barangs[pesan].getHarga()));
					System.out.print("Masukkan Jumlah Uang : ");
					uang = scanner.nextInt();
					
					if(uang < (jmlh * barangs[pesan].getHarga()))
					{
						System.out.println("Jumlah Uang Tidak Mencukupi");
					}
					else if(uang > (jmlh * barangs[pesan].getHarga()))
					{
						barangs[pesan].minusStock(jmlh);
						System.out.println("Berhasil Dipesan");
						System.out.println("Kembalian Anda Rp " + (uang - (jmlh * barangs[pesan].getHarga())));
						count = inputPesanan(count,jmlh, pesan);
					}
					else 
					{
						barangs[pesan].minusStock(jmlh);
						System.out.println("Berhasil Dipesan");
						count = inputPesanan(count,jmlh, pesan);
					}
				}
			}
			else if(pilihan == 2)
			{
				showPesanan(count);
				
				System.out.print("Ketik 0 Untuk Kembali Ke Menu ");
				input = scanner.nextInt();
				
				while (input != 0) 
				{
					input = scanner.nextInt();
				}
			}
			else if(pilihan == 0)
			{
				break;
			}
			else
			{
				continue;
			}
			
		}
		
		scanner.close();
	}
}
