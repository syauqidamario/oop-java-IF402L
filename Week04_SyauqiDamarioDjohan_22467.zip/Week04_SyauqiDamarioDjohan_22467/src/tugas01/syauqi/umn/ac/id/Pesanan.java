package tugas01.syauqi.umn.ac.id;

public class Pesanan {
	private int Id;
	private int jumlah;
	private Barang barang;
	
	public Pesanan()
	{
		
	}
	
	public Pesanan (int Id, int jumlah, Barang barang)
	{
		this.Id = Id;
		this.jumlah = jumlah;
		this.barang = barang;
	}
	
	public int getId()
	{
		return Id;
	}
	
	public int getJumlah()
	{
		return jumlah;
	}
	
	public Barang getBarang()
	{
		return barang;
	}
	
	public static int total(int jumlah, Barang barang) {
		int total;
		total = jumlah * barang.getHarga();
		return total;
	}
}