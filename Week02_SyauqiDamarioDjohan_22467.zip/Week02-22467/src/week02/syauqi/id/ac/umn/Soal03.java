package week02.syauqi.id.ac.umn;
import java.util.Scanner;

public class Soal03 {
	public static void main(String[] args) {
		
			//inisialisasi
			int min;
			int max;
			int primeflag;
			int printflag = 0;
			int curr;
			int ctr;
			int total = 0;
			
			//input program
			Scanner scanner01 = new Scanner(System.in);
			System.out.print("Masukkan nilai terkecil : ");
			Scanner scanner02 = new Scanner(System.in);
			min = scanner01.nextInt();
			System.out.print("Masukkan nilai terbesar : ");
			max = scanner02.nextInt();
			scanner01.close();
			scanner02.close();
			curr = min;
			if(min < 0 || max < 0){
				System.out.println("Angka tidak boleh negatif");
			}
			else if(min > max){
				System.out.println("Angka terkecil lebih besar dari Angka terbesar");
			}
			else{
				while(curr <= max){
					primeflag = 0;
					for(ctr = 2; ctr < curr; ctr++){
						if(curr % ctr == 0){
							primeflag = 1;
							break;
						}
					}
					if(primeflag == 0){
						printflag = 1;
						total = total + curr;
					}
					curr++;
				}
			}
			//OUTPUT
			if(printflag == 1){
				System.out.println("Jumlah dari semua nilai prima diantara " + min + " sampai " + max + " adalah " + total);
			}
	}

}
