package week02.syauqi.id.ac.umn;
import java.util.Scanner;

public class Soal02 {
	public static void main(String[] args) {
		boolean checkPrime = true;
		Scanner sc = new Scanner(System.in);
		System.out.println("Masukkan angka:");
		int number = sc.nextInt();
		
		int a = 2;
		while(a <= number / 2) {
			if(number % a == 0)
			{
				checkPrime = false;
				break;
			}
			a++;
		}
		
		if(checkPrime)
			System.out.println("Angka" + " " + number + " " + "adalah bilangan prima\n");
		else 
			System.out.println("Angka" + " " + number + " " + "bukan bilangan prima\n");
		sc.close();
	}
}
