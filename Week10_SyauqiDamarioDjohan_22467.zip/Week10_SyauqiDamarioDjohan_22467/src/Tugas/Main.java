package Tugas;

import java.util.Scanner;
import Model.Barang;
import Model.Handphone;
import Model.Order;
import Model.Voucher;

public class Main {
	static Barang[] barang = new Barang[200];
	static Order[] order = new Order[200];
	static int count_v = 0, count_h = 0, count_o = 0, count_b = 0;
	
	public static String check_Id(String id) {
		for(int i = 0;i < count_b; i++) {
			if(id.contentEquals(barang[i].getId()))
				return id;
		}
		return "tidak ada";
	}
	
	public static int check_Idx(String id){
		for(int i = 0; i < count_b; i++){
			if(id.equals(barang[i].getId()))
				return i;
		}
		return -1;
	}
	
	public static void pesanbarang(Scanner s) {
		System.out.println("Ketik 0 untuk batal");
		System.out.print("Pesan barang (ID) : ");
		String id = s.nextLine();
		
		String cek = check_Id(id);
		if(cek != "tidak ada") {
			int idx = check_Idx(id);
			System.out.print("Masukkan jumlah : ");
			int jumlah = s.nextInt();
			s.nextLine();
			
			if(id.contains("H")) {
				Handphone hp = (Handphone)barang[idx];
				
				if(jumlah > 0 && jumlah <= hp.getStok()){
					double total = jumlah*hp.getHarga();
					System.out.printf("%d @ %s dengan total harga %.0f\n", jumlah, hp.getNama(), total);
					System.out.print("Masukkan jumlah uang : ");
					int uang = s.nextInt();
					s.nextLine();

					if(uang < total){
						System.out.println("Jumlah uang tidak mencukupi\n");
					}
					else {
						order[count_o] = new Order(id,hp,jumlah);
						Handphone.total += total;
						count_o++;
						hp.minusStock(jumlah);
						System.out.println("Berhasil dipesan\n");
					}
				}
				else {
					System.out.println("Stok tidak mencukupi\n");
				}
			}
			else if(id.contains("V")){
				Voucher voucher = (Voucher)barang[idx];
				
				if(jumlah > 0 && jumlah <= voucher.getStok()){
					double total = jumlah * voucher.getHargaJual();
					System.out.printf("%d @ %s dengan total harga %.0f\n", jumlah, voucher.getNama(), total);
					System.out.print("Masukkan jumlah uang : ");
					int uang = s.nextInt();
					s.nextLine();

					if(uang < total){
						System.out.println("Jumlah uang tidak mencukupi\n");
					}
					else {
						order[count_o] = new Order(id,voucher,jumlah);
						Voucher.total += total;
						count_o++;
						voucher.minusStock(jumlah);
						System.out.println("Berhasil dipesan\n");
					}
				}
				else {
					System.out.println("Stok tidak mencukupi\n");
				}
			}
		}
		else {
			System.out.println("Barang tidak ditemukan!\n");
		}
	}
	
	public static void lihatbarang() {
		System.out.println("Daftar Pesanan Toko Multiguna");
		for(int i = 0; i<count_o; i++)
		{
			System.out.println("ID      : "+order[i].getId());
			if(order[i].getId().contains("OH")) {
				System.out.println("Nama    : "+order[i].getHandphone().getNama());
				System.out.println("Jumlah  : "+order[i].getJumlah());
				System.out.println("Total   : "+Handphone.total);
				System.out.println("------------------------------------------");
			}
			else{
				System.out.println("Nama    : "+order[i].getVoucher().getNama());
				System.out.println("Jumlah  : "+order[i].getJumlah());
				System.out.println("Total   : "+Voucher.total);
				System.out.println("------------------------------------------");
			}
		}
	}
	
	public static void barangbaru(Scanner s) {
		System.out.print("Voucher /  Handphone (V/H) : ");
		char brng = s.next().charAt(0); s.nextLine();
		System.out.print("Nama : ");
		String nama = s.nextLine();
		System.out.print("Harga : ");
		int harga = s.nextInt(); s.nextLine();
		System.out.print("Stok : ");
		int stok = s.nextInt(); s.nextLine();

		if(brng == 'v' || brng == 'V') {
			System.out.print("PPN : ");
			double ppn = s.nextDouble(); s.nextLine();
			
			count_v++;
			Voucher voucher = new Voucher("V0" + count_v,nama,harga,stok,ppn);
			barang[count_b] = (Barang)voucher;
			count_b++;
			System.out.println("Voucher telah berhasil diinput\n");
		}
		else if(brng == 'h' || brng == 'H') {
			System.out.print("Warna : ");
			String warna = s.next();
			s.nextLine();
			
			count_h++;
			Handphone hp = new Handphone("H0"+count_h,nama,harga,stok,warna);
			barang[count_b] = (Barang)hp;
			count_b++;
			System.out.println("Handphone telah berhasil diinput\n");
		}
	}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		int option;
		
		while(true) {
			System.out.println("---------Menu Toko Voucher & HP------------");
			System.out.println("1. Pesan Barang");
			System.out.println("2. Lihat Pesanan");
			System.out.println("3. Barang Baru");
			System.out.print("Pilihan : ");
			option = s.nextInt(); s.nextLine();
			
			if(option == 1) {
				System.out.println("Daftar Barang Toko Voucher & HP");
				for(int idx = 0; idx < count_b; idx++)
				{
					if(barang[idx].getId().contains("H")) {
						Handphone hp = (Handphone)barang[idx];
						
						System.out.println("ID      : "+hp.getId());
						System.out.println("Nama    : "+hp.getNama()+" "+hp.getWarna());
						System.out.println("Stok    : "+hp.getStok());
						System.out.printf("Harga   : %.0f\n", hp.getHarga());
					}
					else {
						Voucher voucher = (Voucher)barang[idx];
						
						System.out.println("ID      : "+voucher.getId());
						System.out.println("Nama    : "+voucher.getNama());
						System.out.printf("Nominal : %.0f\n", voucher.getHarga());
						System.out.println("Stok    : "+voucher.getStok());
						System.out.printf("Harga   : %.0f\n", voucher.getHargaJual());
					}
					System.out.println("-------------------------------");
				}
				pesanbarang(s);
			}
			else if(option == 2) {
				lihatbarang();
			}
			else if(option== 3) {
				barangbaru(s);
			}
		}
	}
}