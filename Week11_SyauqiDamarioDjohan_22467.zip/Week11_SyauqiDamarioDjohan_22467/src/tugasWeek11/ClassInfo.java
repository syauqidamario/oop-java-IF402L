package tugasWeek11;

public interface ClassInfo {
	public String getClassName();
}