package tugasWeek11;

public class Credit extends Payment{
	protected int installment;
	protected int maxInstallmentAmount;
	
	public Credit() {
		
	}

	public Credit(Item item, int maxInstallmentAmount) {
		super(item);
		this.maxInstallmentAmount = maxInstallmentAmount;
		this.installment = 0;
	}
	
	public int pay(int bayar) {
		if(isPaidOff) {
			return 0;
		}
		
		installment = installment + bayar;
		
		if(installment == item.getPrice()) {
			isPaidOff = true;
			return 0;
		}
		
		return (this.item.getPrice() / maxInstallmentAmount);
	}
	
	public int getRemainingAmount() {
		if(isPaidOff) {
			return 0;
		}
		return (this.item.getPrice() / maxInstallmentAmount);
	}
	
	public String getClassName() {
		return "CREDIT";
	}
}
