package week03.syauqi.id.ac.umn;

import java.util.Scanner;

public class Tugas02 {
	
	public static void charat(String nama){
		System.out.println("-----charAt-----");
		System.out.println("Nama : " + nama);
		System.out.print("Input : ");
		Scanner scanner = new Scanner(System.in);
		int input = scanner.nextInt();
		scanner.close();
		System.out.println("Hasil : " + nama.charAt(input));
	}
	
	public static void panjang(String nama){
		System.out.println("-----length-----");
		System.out.println("Nama : " + nama);
		System.out.print("Input : ");
		System.out.print(nama.length());
	}
	
	public static void sub(String nama){
		System.out.println("-----substring(n)-----");
		System.out.println("Nama : " + nama);
		System.out.print("Input : ");
		Scanner scanner = new Scanner(System.in);
		int input = scanner.nextInt();
		scanner.close();
		System.out.println("Hasil : " + nama.substring(input));
		
	}
	
	public static void subplus(String nama){
		System.out.println("-----substring(m,n)-----");
		System.out.println("Nama : " + nama);
		System.out.print("Input mulai : ");
		Scanner scanner = new Scanner(System.in);
		int input = scanner.nextInt();
		System.out.print("Input akhir : ");
		Scanner scanner2 = new Scanner(System.in);
		int input2 = scanner2.nextInt();
		scanner.close();
		scanner2.close();
		System.out.println("Hasil : " + nama.substring(input, input2));
		
	}
	
	public static void contain(String nama){
		System.out.println("-----contains-----");
		System.out.println("Nama : " + nama);
		System.out.print("Input : ");
		Scanner scanner = new Scanner(System.in);
		String input = scanner.nextLine();
		scanner.close();
		System.out.println("Hasil : " + nama.contains(input));
		
	}
	
	public static void conc(String nama){
		System.out.println("-----concat-----");
		System.out.println("Nama : " + nama);
		System.out.print("Input : ");
		Scanner scanner = new Scanner(System.in);
		String input = scanner.nextLine();
		scanner.close();
		System.out.println("Hasil : " + nama.concat(input));
		
	}
	
	public static void replace(String nama){
		System.out.println("-----substring(n)-----");
		System.out.println("Nama : " + nama);
		System.out.print("Input kata yang diganti : ");
		Scanner scanner = new Scanner(System.in);
		String input = scanner.nextLine();		
		System.out.print("Input kata pengganti    : ");
		Scanner scanner2 = new Scanner(System.in);
		String input2 = scanner2.nextLine();
		scanner.close();
		scanner2.close();
		System.out.println("Hasil : " + nama.replace(input, input2));
		
	}
	
	public static void split(String nama){
		System.out.println("-----contains-----");
		System.out.println("Nama : " + nama);
		System.out.print("Input : ");
		Scanner scanner = new Scanner(System.in);
		String input = scanner.nextLine();
		scanner.close();
		String[] bagiannama = nama.split(input);
		for(String nama1 : bagiannama){
			System.out.println("Hasil : " + nama1);
		}
		
	}
	
	public static void lower(String nama){
		System.out.println("-----lowerCase-----");
		System.out.println("Nama : " + nama);
		System.out.println("Hasil : " + nama.toLowerCase());
	
	}
	
	public static void upper(String nama){
		System.out.println("-----upperCase-----");
		System.out.println("Nama : " + nama);
		System.out.println("Hasil : " + nama.toUpperCase());
	
	}
	
	public static void main(String[] args) {
		int input;
		System.out.print("Masukkan Nama Anda : ");
		Scanner scanner = new Scanner(System.in);
		String nama = scanner.nextLine();
		System.out.println("-----------------------------------");
		System.out.println("String anda : " + nama);
		System.out.println("1. charAt               2. length");
		System.out.println("3. substring(n)         4. substring(m,n)");
		System.out.println("5. contains             6. concat");
		System.out.println("7. replace              8. split");
		System.out.println("9. lowercase            10. upperCase");
		System.out.print("Pilih menu : ");
		input = scanner.nextInt();
		switch(input){
		case 1: charat(nama);break;
		case 2: panjang(nama);break;
		case 3: sub(nama);break;
		case 4: subplus(nama);break;
		case 5: contain(nama);break;
		case 6: conc(nama);break;
		case 7: replace(nama);break;
		case 8: split(nama);break;
		case 9: lower(nama);break;
		case 10: upper(nama);break;
		default: break;
		}
		scanner.close();
	}
}
