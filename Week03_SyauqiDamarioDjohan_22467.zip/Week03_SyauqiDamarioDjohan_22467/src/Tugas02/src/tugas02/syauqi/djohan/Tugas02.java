package tugas02.syauqi.djohan;

public class Tugas02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
