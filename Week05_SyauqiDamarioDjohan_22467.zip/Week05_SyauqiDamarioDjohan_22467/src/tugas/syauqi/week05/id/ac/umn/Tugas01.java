package tugas.syauqi.week05.id.ac.umn;

import java.util.Scanner;

public class Tugas01 {
	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);

		int jari, sisi, panjang, lebar, alas, tinggi;
		
		for(;;)
		{
			System.out.println("--------Program Menghitung Luas Bangun Ruang--------");
			System.out.println("1. Lingkaran");
			System.out.println("2. Persegi");
			System.out.println("3. Persegi Panjang");
			System.out.println("4. Segitiga");
			System.out.println("5. Keluar");
			System.out.print("Pilihan : ");
			int pilih = scanner.nextInt();

			if (pilih == 1)
			{
				System.out.println("-----------Lingkaran-----------");
				System.out.print("Masukkan Jari-Jari \t : ");
				jari = scanner.nextInt();

				Lingkaran lingkaran = new Lingkaran(jari, "Biru");

				System.out.println("Warna \t\t\t : " + lingkaran.getWarna());
				System.out.println("Jari-Jari \t\t : " + lingkaran.getRadius());
				System.out.println("Keliling Lingkaran \t : " + lingkaran.getKeliling());
				System.out.println("Luas Lingkaran \t\t : " + lingkaran.getLuas());
			}
			else if(pilih == 2)
			{
				System.out.println("-----------Persegi-----------");
				System.out.print("Masukkan Panjang Sisi \t : ");
				sisi = scanner.nextInt();

				Persegi persegi = new Persegi(sisi, "Merah");

				System.out.println("Warna \t\t\t : " + persegi.getWarna());
				System.out.println("Jari-Jari \t\t : " + persegi.getSisi());
				System.out.println("Keliling Lingkaran \t : " + persegi.getKeliling());
				System.out.println("Luas Lingkaran \t\t : " + persegi.getLuas());
			}
			else if(pilih == 3)
			{
				System.out.println("-----------Persegi Panjang-----------");
				System.out.print("Masukkan Panjang \t : ");
				panjang = scanner.nextInt();
				System.out.print("Masukkan Lebar \t\t : ");
				lebar = scanner.nextInt();

				PersegiPanjang persegiPanjang = new PersegiPanjang(panjang, "Ungu", lebar);

				System.out.println("Warna \t\t\t : " + persegiPanjang.getWarna());
				persegiPanjang.getPanjangLebar();
				System.out.println("Keliling Persegi Panjang : " + persegiPanjang.getKeliling());
				System.out.println("Luas Persegi Panjang \t : " + persegiPanjang.getLuas());
			}
			else if(pilih == 4)
			{
				System.out.println("-----------Segitiga Siku-Siku-----------");
				System.out.print("Masukkan Alas \t\t : ");
				alas = scanner.nextInt();
				System.out.print("Masukkan Tinggi \t : ");
				tinggi = scanner.nextInt();

				Segitiga segitiga = new Segitiga(alas, tinggi, "Hitam");

				System.out.println("Warna \t\t\t : " + segitiga.getWarna());
				segitiga.getAlasTinggi();
				System.out.println("Keliling Segitiga \t : " + segitiga.getKeliling());
				System.out.println("Luas Segitiga \t\t : " + segitiga.getLuas());
			}
			else if(pilih == 5)
			{
				System.out.println("Keluar Program...");
				scanner.close();
				break;
			}
			else
			{
				System.out.println("Input Tidak Valid");

				continue;
			}
		}
	}
}

	