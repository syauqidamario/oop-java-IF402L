package tugas.syauqi.week05.id.ac.umn;

public class Segitiga extends BangunRuang
{
	private double alas;
	private double tinggi;

	public Segitiga()
	{

	}

	public Segitiga(int alas, int tinggi, String color)
	{
		super(color);
		this.alas = alas;
		this.tinggi = tinggi;
	}

	public void getAlasTinggi()
	{
		System.out.println("Alas & Tinggi \t\t : " + alas + " & " + tinggi);
	}

	public double getKeliling()
	{
		return alas + tinggi + (Math.sqrt((alas * alas) + (tinggi * tinggi)));
	}

	public double getLuas()
	{
		return (alas * tinggi) / 2;
	}

}