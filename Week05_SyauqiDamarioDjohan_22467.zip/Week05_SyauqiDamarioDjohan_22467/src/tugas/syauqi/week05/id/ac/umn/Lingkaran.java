package tugas.syauqi.week05.id.ac.umn;

public class Lingkaran extends BangunRuang {
	private double radius;
	
	public Lingkaran()
	{
		
	}
	
	public Lingkaran(double radius, String warna) {
		super(warna);
		this.radius = radius;
	}
	
	public double getRadius() {
		return radius;
	}
	
	public double getLuas() {
		return Math.PI * radius * radius;
	}
	
	public double getKeliling() {
		return Math.PI * 2 * radius;
	}

}
