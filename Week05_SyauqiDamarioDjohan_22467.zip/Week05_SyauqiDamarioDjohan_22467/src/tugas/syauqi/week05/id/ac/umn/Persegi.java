package tugas.syauqi.week05.id.ac.umn;

public class Persegi extends BangunRuang {
	private double sisi;
	
	public Persegi()
	{
		
	}
	
	public Persegi(double sisi, String warna) {
		super(warna);
		this.sisi = sisi;
	}
	
	public double getSisi() {
		return sisi;
	}
	
	public double getLuas() {
		return sisi * sisi;
	}
	
	public double getKeliling() {
		return 4 * sisi;
	}

}
