package tugas.syauqi.week05.id.ac.umn;

public class PersegiPanjang extends BangunRuang
{
	private double panjang;
	private double lebar;

	public PersegiPanjang()
	{

	}

	public PersegiPanjang(int panjang, String color, int lebar)
	{
		super(color);
		this.panjang = panjang;
		this.lebar = lebar;
	}

	public void getPanjangLebar()
	{
		System.out.println("Panjang & Lebar \t : " + panjang + " & " + lebar);
	}

	public double getKeliling()
	{
		return 2 * (panjang + lebar);
	}

	public double getLuas()
	{
		return panjang * lebar;
	}
}
