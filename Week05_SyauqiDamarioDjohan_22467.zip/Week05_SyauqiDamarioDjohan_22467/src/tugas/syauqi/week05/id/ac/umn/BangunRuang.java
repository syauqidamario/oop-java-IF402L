package tugas.syauqi.week05.id.ac.umn;

public class BangunRuang {
	private String warna;
	
	public BangunRuang()
	{
		
	}
	
	public BangunRuang(String warna)
	{
		this.warna = warna;
	}
	
	public void setWarna(String warna)
	{
		this.warna = warna;
	}
	
	public String getWarna()
	{
		return warna;
	}
	
	public double getLuas()
	{
		return 0;
	}
	
	public double getKeliling()
	{
		return 0;
	}

}
